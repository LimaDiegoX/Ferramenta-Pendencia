from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from pathlib import Path
import shutil
from files.credentials import cred
import time as t


class In:
    def run(self):
        self.check_file()
        window = self.start()
        t.sleep(5)
        self.select_cred_mode(window)
        self.access(window)


    def start(self):
        servico = Service(ChromeDriverManager().install())
        janela = webdriver.Chrome(service=servico)
        janela.get('https://camop-sci.sce.manh.com/bi/?perspective=authoring&id=iBD3E118D2A1743F7A026A71383B1CD2B&objRef=iBD3E118D2A1743F7A026A71383B1CD2B&action=run&format=xlsxData&cmPropStr=%7B%22id%22%3A%22iBD3E118D2A1743F7A026A71383B1CD2B%22%2C%22type%22%3A%22report%22%2C%22defaultName%22%3A%22mapa%20linhas%20in%22%2C%22permissions%22%3A%5B%22execute%22%2C%22read%22%2C%22setPolicy%22%2C%22traverse%22%2C%22write%22%5D%7D')        
        return janela

    def select_cred_mode(self,driver):
        wait = WebDriverWait(driver, 120)
        try:
            element = wait.until(EC.element_to_be_clickable((By.NAME, 'CAMNamespace')))
            driver.find_element(by=By.NAME,value='CAMNamespace').click()
            driver.find_element(by=By.NAME,value='CAMNamespace').send_keys(Keys.ARROW_UP)
            driver.find_element(by=By.NAME,value='CAMNamespace').send_keys(Keys.ARROW_UP)
            driver.find_element(by=By.NAME,value='CAMNamespace').send_keys(Keys.ENTER)
            return 1
        except:
            return 0

    def access(self,driver):
        wait = WebDriverWait(driver, 10)
        try:
            element = wait.until(EC.element_to_be_clickable((By.NAME, 'username')))
            driver.find_element(by=By.NAME,value='username').send_keys(cred.login)
            driver.find_element(by=By.NAME,value='username').send_keys(Keys.ENTER)
            element = wait.until(EC.element_to_be_clickable((By.NAME, 'password')))
            driver.find_element(by=By.NAME,value='password').send_keys(cred.senha)
            driver.find_element(by=By.NAME,value='password').send_keys(Keys.ENTER)
            downloads_old = len(list((Path.home()/'Downloads').iterdir()))
            arquivo_movido = False
            for i in range(20):
                if arquivo_movido:
                    break

                caminho_origem = Path.home()/'Downloads'
                caminho_destino = Path.cwd()/'databases'
                downloads_new = len(list((Path.home()/'Downloads').iterdir()))
                if downloads_new > downloads_old:
                    for arquivo in caminho_origem.iterdir():
                        while arquivo.is_file() and arquivo.name.endswith("load"):
                            t.sleep(3)
                        if (caminho_origem/Path("mapa linhas in.xlsx")).exists():
                            shutil.move((caminho_origem/Path("mapa linhas in.xlsx")),(caminho_destino/Path("inbound.xlsx")))
                            arquivo_movido = True
                            driver.close()
                            break
                t.sleep(5)
                
        except:
            return 0

    # def dowload(self,driver):        
    #     elementos = driver.find_elements(by=By.TAG_NAME,value='tr')
    #     downloads_old = len(list((Path.home()/'Downloads').iterdir()))
    #     status = None
    #     for i in range(10):
    #         teste = len(elementos)
    #         t.sleep(3)
    #         elementos = driver.find_elements(by=By.TAG_NAME,value='tr')
    #         if teste == 8 :
    #             wait = WebDriverWait(driver, 300)
    #             element = wait.until(EC.element_to_be_clickable((By.ID, 'com.ibm.bi.authoring.runBtn.menu')))
    #             # t.sleep(2)
    #             driver.find_element(by=By.ID,value='com.ibm.bi.authoring.runBtn.menu').click()
    #             # t.sleep(2)
    #             wait = WebDriverWait(driver, 300)
    #             element = wait.until(EC.element_to_be_clickable((By.ID, 'view77_item81')))
    #             driver.find_element(by=By.ID,value='view77_item81').click()
    #             for i in range(10):
    #                 t.sleep(2)
    #                 caminho_origem = Path.home()/'Downloads'
    #                 caminho_destino = Path.cwd()/'databases'
    #                 downloads_new = len(list((Path.home()/'Downloads').iterdir()))
    #                 if downloads_new > downloads_old:
    #                     if (caminho_origem/Path("mapa linhas in.xlsx")).exists():
    #                         shutil.move((caminho_origem/Path("mapa linhas in.xlsx")),(caminho_destino/Path("inbound.xlsx")))
    #                         status = "ok"
    #         if status == "ok":
    #             break
                    
    def check_file(self):
        caminho = Path.cwd()/'databases'
        if caminho.exists() == False:
            Path(Path.cwd()/'databases').mkdir()
        if(caminho/Path("inbound.xlsx")).exists():
            (caminho/Path("inbound.xlsx")).unlink()
