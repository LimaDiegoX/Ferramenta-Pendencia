from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from datetime import datetime, timedelta
from pathlib import Path
import shutil
from files.credentials import cred
import time as t

class Pendencia:
    def run(self):
        self.check_file()
        window = self.start()
        t.sleep(5)
        self.select_cred_mode(window)
        self.access(window)
        # self.dowload(window)


    def start(self):
        servico = Service(ChromeDriverManager().install())
        janela = webdriver.Chrome(service=servico)
        janela.get('https://camop-sci.sce.manh.com/bi/?perspective=authoring&id=i12FDEDCDA0C8437293CC254A2E585BFB&objRef=i12FDEDCDA0C8437293CC254A2E585BFB&action=run&format=xlsxData&cmPropStr=%7B%22id%22%3A%22i12FDEDCDA0C8437293CC254A2E585BFB%22%2C%22type%22%3A%22report%22%2C%22defaultName%22%3A%22Base%20Pend%C3%AAncia%20PO%2FASN%22%2C%22permissions%22%3A%5B%22execute%22%2C%22read%22%2C%22setPolicy%22%2C%22traverse%22%2C%22write%22%5D%7D')        
        return janela

    def select_cred_mode(self,driver):
        wait = WebDriverWait(driver, 10)
        try:
            element = wait.until(EC.element_to_be_clickable((By.NAME, 'CAMNamespace')))
            driver.find_element(by=By.NAME,value='CAMNamespace').click()
            driver.find_element(by=By.NAME,value='CAMNamespace').send_keys(Keys.ARROW_UP)
            driver.find_element(by=By.NAME,value='CAMNamespace').send_keys(Keys.ARROW_UP)
            driver.find_element(by=By.NAME,value='CAMNamespace').send_keys(Keys.ENTER)
            return 1
        except:
            return 0

    def access(self,driver):
        wait = WebDriverWait(driver, 20)
        try:
            element = wait.until(EC.element_to_be_clickable((By.NAME, 'username')))
            driver.find_element(by=By.NAME,value='username').send_keys(cred.login)
            driver.find_element(by=By.NAME,value='username').send_keys(Keys.ENTER)
            element = wait.until(EC.element_to_be_clickable((By.NAME, 'password')))
            driver.find_element(by=By.NAME,value='password').send_keys(cred.senha)
            driver.find_element(by=By.NAME,value='password').send_keys(Keys.ENTER)
            iframes = []
            while len(iframes) == 0 or len(iframes) == 1:
                body = driver.find_element(by=By.TAG_NAME,value='body')
                div = body.find_element(by=By.XPATH,value='/html/body/div[1]')
                iframes = div.find_elements(by=By.TAG_NAME,value='iframe')
                t.sleep(4)

            driver.switch_to.frame(iframes[1])
            body = driver.find_element(by=By.TAG_NAME,value='body')
            ch_ch_divs = body.find_elements(by=By.TAG_NAME,value='div')
            for div in ch_ch_divs:
                classe = div.get_attribute('class')
                if classe == 'clsViewerPage':
                    # data_atual = datetime.now()
                    # data_anterior = data_atual - timedelta(days=1)
                    # if data_anterior.month != data_atual.month:
                    #     primeiro_dia_do_mes_atual = data_atual.replace(day=1)
                    #     data_passado = primeiro_dia_do_mes_atual - timedelta(days=1)
                    # else:
                    #     data_passado = data_anterior
                    # data = data_passado.strftime("%d/%m/%Y") 
                    div.find_element(By.ID,'dv16').send_keys(Keys.TAB)
                    div.find_element(By.ID,'dv18__tblDateTextBox__txtInput').send_keys(cred.data)
                    div.find_element(By.ID,'dv29').click()

            downloads_old = len(list((Path.home()/'Downloads').iterdir()))
            arquivo_movido = False
            for i in range(20):
                if arquivo_movido:
                    break

                caminho_origem = Path.home()/'Downloads'
                caminho_destino = Path.cwd()/'databases'
                downloads_new = len(list((Path.home()/'Downloads').iterdir()))
                if downloads_new > downloads_old:
                    for arquivo in caminho_origem.iterdir():
                        if arquivo.is_file() and arquivo.name.endswith("load"):
                            t.sleep(3)
                        else:
                            if (caminho_origem/Path("Base Pendência PO_ASN.xlsx")).exists():
                                shutil.move((caminho_origem/Path("Base Pendência PO_ASN.xlsx")),(caminho_destino/Path("pendencia.xlsx")))
                                arquivo_movido = True
                                driver.close()
                                break
                t.sleep(5)
            driver.close()
        except:
            return 0

    # def dowload(self,driver):        
    #     elementos = driver.find_elements(by=By.TAG_NAME,value='tr')
    #     downloads_old = len(list((Path.home()/'Downloads').iterdir()))
    #     status = None
    #     for i in range(10):
    #         teste = len(elementos)
    #         t.sleep(3)
    #         elementos = driver.find_elements(by=By.TAG_NAME,value='tr')
    #         if teste == 8 :
    #             wait = WebDriverWait(driver, 300)
    #             element = wait.until(EC.element_to_be_clickable((By.ID, 'com.ibm.bi.authoring.runBtn.menu')))
    #             t.sleep(2)
    #             driver.find_element(by=By.ID,value='com.ibm.bi.authoring.runBtn.menu').click()
    #             t.sleep(2)
    #             driver.find_element(by=By.ID,value='view77_item81').click()
    #             for i in range(10):
    #                 t.sleep(2)
    #                 caminho_origem = Path.home()/'Downloads'
    #                 caminho_destino = Path.cwd()/'databases'
    #                 downloads_new = len(list((Path.home()/'Downloads').iterdir()))
    #                 if downloads_new > downloads_old:
    #                     if (caminho_origem/Path("mapa linhas out.xlsx")).exists():
    #                         shutil.move((caminho_origem/Path("mapa linhas out.xlsx")),(caminho_destino/Path("outbound.xlsx")))
    #                         status = "ok"
    #         if status == "ok":
    #             break
                    
    def check_file(self):
        caminho = Path.cwd()/'databases'
        if caminho.exists() == False:
            Path(Path.cwd()/'databases').mkdir()
        if(caminho/Path("pendencia.xlsx")).exists():
            (caminho/Path("pendencia.xlsx")).unlink()
